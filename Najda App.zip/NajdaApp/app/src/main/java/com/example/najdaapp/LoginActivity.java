package com.example.najdaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.TableLayout;
import android.support.design.widget.TabLayout;


public class LoginActivity extends AppCompatActivity {
 TabLayout
    TabLayout tabLayout;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
//        tabLayout=findViewById(R.id.tab_layout);
//        viewPager =findViewById(R.id.view_pager);
//        tabLayout.addTab(tabLayout.newTab().setText("Login"));
//        tabLayout.setGravity(TableLayout.GR);

    }
}
